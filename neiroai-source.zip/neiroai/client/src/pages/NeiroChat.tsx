import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Menu, Plus, History, Settings, Zap, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { ChatInterface, ChatMessage } from "@/components/ChatInterface";
import { OrbIntro } from "@/components/OrbIntro";
import { CommandPalette } from "@/components/CommandPalette";
import { trpc } from "@/lib/trpc";
import { nanoid } from "nanoid";
import SettingsPage from "./Settings";

export default function NeiroChat() {
  const [showIntro, setShowIntro] = useState(true);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState<"netrom3" | "nemotron" | "neiroplus">("neiroplus");
  const [chatHistory, setChatHistory] = useState<{ id: string; title: string; timestamp: Date }[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [showCommandPalette, setShowCommandPalette] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Load chat history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("neiroai_chat_history");
    if (saved) {
      try {
        setChatHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load chat history:", e);
      }
    }
  }, []);

  // Save chat history to localStorage
  useEffect(() => {
    localStorage.setItem("neiroai_chat_history", JSON.stringify(chatHistory));
  }, [chatHistory]);

  // Handle command palette trigger
  useEffect(() => {
    if (inputValue.startsWith("/")) {
      setShowCommandPalette(true);
    } else {
      setShowCommandPalette(false);
    }
  }, [inputValue]);

  const handleSendMessage = async (content: string) => {
    const userMessage: ChatMessage = {
      id: nanoid(),
      role: "user",
      content,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);
    setInputValue("");

    // Create abort controller for this request
    abortControllerRef.current = new AbortController();

    try {
      // Call tRPC chat router
      // Call tRPC chat router
      const utils = trpc.useUtils();
      const { mutateAsync } = trpc.chat.sendMessage.useMutation();
      
      const response = await mutateAsync({
        message: content,
        model: selectedModel,
        conversationHistory: messages.map((m) => ({
          role: m.role,
          content: m.content,
        })),
      });

      if (response.success && response.response) {
        const assistantMessage: ChatMessage = {
          id: nanoid(),
          role: "assistant",
          content: response.response || "No response",
          timestamp: new Date(),
        };

        setMessages((prev) => [...prev, assistantMessage]);

        // Auto-generate chat title if this is the first message
        if (chatHistory.length === 0 && messages.length === 1) {
          const title = content.substring(0, 50) + (content.length > 50 ? "..." : "");
          setChatHistory([
            {
              id: nanoid(),
              title,
              timestamp: new Date(),
            },
          ]);
        }
      } else {
        // Show error message
        const errorMessage: ChatMessage = {
          id: nanoid(),
          role: "assistant",
          content: `Error: ${"error" in response ? response.error : "Failed to get response"}`,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, errorMessage]);
      }
    } catch (error) {
      console.error("Error sending message:", error);
      const errorMessage: ChatMessage = {
        id: nanoid(),
        role: "assistant",
        content: "Sorry, an error occurred. Please try again.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleStop = () => {
    setIsLoading(false);
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setMessages((prev) => {
      const updated = [...prev];
      const lastMsg = updated[updated.length - 1];
      if (lastMsg && lastMsg.role === "assistant") {
        lastMsg.isStreaming = false;
      }
      return updated;
    });
  };

  const handleNewChat = () => {
    setMessages([]);
    setInputValue("");
    inputRef.current?.focus();
  };

  const handleCommandSelect = (command: any) => {
    // Handle command selection
    const commandText = command.label;
    setInputValue(commandText + " ");
    setShowCommandPalette(false);
    inputRef.current?.focus();
  };

  if (showIntro) {
    return <OrbIntro onComplete={() => setShowIntro(false)} />;
  }

  if (showSettings) {
    return <SettingsPage onBack={() => setShowSettings(false)} />;
  }

  return (
    <div className="flex h-screen bg-background text-foreground">
      {/* Sidebar */}
      <Sheet>
        <SheetTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="fixed top-4 left-4 z-40 md:hidden"
          >
            <Menu className="w-5 h-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 bg-card border-r border-border p-0">
          <SidebarContent
            onNewChat={handleNewChat}
            chatHistory={chatHistory}
            selectedModel={selectedModel}
            onModelChange={setSelectedModel}
            onSettings={() => setShowSettings(true)}
          />
        </SheetContent>
      </Sheet>

      {/* Desktop Sidebar */}
      <div className="hidden md:flex w-64 flex-col bg-card border-r border-border">
        <SidebarContent
          onNewChat={handleNewChat}
          chatHistory={chatHistory}
          selectedModel={selectedModel}
          onModelChange={setSelectedModel}
          onSettings={() => setShowSettings(true)}
        />
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col relative">
        <ChatInterface
          messages={messages}
          isLoading={isLoading}
          onSendMessage={handleSendMessage}
          onStop={handleStop}
        />

        {/* Command Palette - positioned above input */}
        <div className="absolute bottom-20 left-4 right-4 md:left-6 md:right-6">
          <CommandPalette
            isOpen={showCommandPalette}
            onClose={() => setShowCommandPalette(false)}
            onCommandSelect={handleCommandSelect}
            inputValue={inputValue}
          />
        </div>
      </div>
    </div>
  );
}

interface SidebarContentProps {
  onNewChat: () => void;
  chatHistory: { id: string; title: string; timestamp: Date }[];
  selectedModel: "netrom3" | "nemotron" | "neiroplus";
  onModelChange: (model: "netrom3" | "nemotron" | "neiroplus") => void;
  onSettings: () => void;
}

function SidebarContent({
  onNewChat,
  chatHistory,
  selectedModel,
  onModelChange,
  onSettings,
}: SidebarContentProps) {
  return (
    <div className="flex flex-col h-full p-4">
      {/* New Chat Button */}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={onNewChat}
        className="flex items-center justify-center gap-2 w-full px-4 py-2 rounded-lg bg-accent text-accent-foreground hover:bg-accent/90 transition-colors mb-6"
      >
        <Plus className="w-4 h-4" />
        <span className="text-sm font-medium">New Chat</span>
      </motion.button>

      {/* Model Selector */}
      <div className="mb-6">
        <p className="text-xs font-semibold text-muted-foreground mb-2 px-2">
          MODEL
        </p>
        <div className="space-y-2">
          {[
            { id: "neiroplus", label: "NeiroPlus", icon: Zap },
            { id: "netrom3", label: "Netrom 3 Ultra", icon: Zap },
            { id: "nemotron", label: "Nemotron Nano", icon: Zap },
          ].map(({ id, label, icon: Icon }) => (
            <motion.button
              key={id}
              whileHover={{ x: 4 }}
              onClick={() => onModelChange(id as any)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors ${
                selectedModel === id
                  ? "bg-accent text-accent-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-card"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{label}</span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Chat History */}
      {chatHistory.length > 0 && (
        <div className="mb-6 flex-1 overflow-y-auto">
          <p className="text-xs font-semibold text-muted-foreground mb-2 px-2">
            HISTORY
          </p>
          <div className="space-y-1">
            {chatHistory.map((chat) => (
              <motion.button
                key={chat.id}
                whileHover={{ x: 4 }}
                className="w-full text-left px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-card transition-colors truncate"
              >
                <History className="w-3 h-3 inline mr-2" />
                {chat.title}
              </motion.button>
            ))}
          </div>
        </div>
      )}

      {/* Settings */}
      <motion.button
        whileHover={{ x: 4 }}
        onClick={onSettings}
        className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-card transition-colors w-full mt-auto"
      >
        <Settings className="w-4 h-4" />
        <span>Settings</span>
      </motion.button>
    </div>
  );
}

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

interface SettingsPageProps {
  onBack: () => void;
}

export default function SettingsPage({ onBack }: SettingsPageProps) {
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [defaultModel, setDefaultModel] = useState<"netrom3" | "nemotron" | "neiroplus">("neiroplus");
  const [animationsEnabled, setAnimationsEnabled] = useState(true);
  const [autoScroll, setAutoScroll] = useState(true);

  // Load settings from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("neiroai_settings");
    if (saved) {
      try {
        const settings = JSON.parse(saved);
        setTheme(settings.theme || "dark");
        setDefaultModel(settings.defaultModel || "neiroplus");
        setAnimationsEnabled(settings.animationsEnabled !== false);
        setAutoScroll(settings.autoScroll !== false);
      } catch (e) {
        console.error("Failed to load settings:", e);
      }
    }
  }, []);

  // Save settings to localStorage
  const saveSettings = () => {
    const settings = {
      theme,
      defaultModel,
      animationsEnabled,
      autoScroll,
    };
    localStorage.setItem("neiroai_settings", JSON.stringify(settings));
    toast.success("Settings saved");
  };

  const handleClearHistory = () => {
    if (confirm("Are you sure you want to clear all chat history? This cannot be undone.")) {
      localStorage.removeItem("neiroai_chat_history");
      toast.success("Chat history cleared");
    }
  };

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 md:p-6 border-b border-border">
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="h-10 w-10"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-bold">Settings</h1>
      </div>

      {/* Settings Content */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6">
        <div className="max-w-2xl space-y-6">
          {/* Appearance */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Appearance</CardTitle>
                <CardDescription>Customize how NeiroAI looks</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="theme">Theme</Label>
                  <Select value={theme} onValueChange={(v) => setTheme(v as any)}>
                    <SelectTrigger id="theme" className="bg-background border-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dark">Dark</SelectItem>
                      <SelectItem value="light">Light</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* AI Models */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>AI Models</CardTitle>
                <CardDescription>Choose your default AI model</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="model">Default Model</Label>
                  <Select value={defaultModel} onValueChange={(v) => setDefaultModel(v as any)}>
                    <SelectTrigger id="model" className="bg-background border-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="neiroplus">NeiroPlus (Recommended)</SelectItem>
                      <SelectItem value="netrom3">Netrom 3 Ultra</SelectItem>
                      <SelectItem value="nemotron">Nemotron Nano Omni</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    NeiroPlus uses multi-model orchestration for better results
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Preferences */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Preferences</CardTitle>
                <CardDescription>Customize your experience</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base">Enable Animations</Label>
                    <p className="text-sm text-muted-foreground">
                      Smooth transitions and effects
                    </p>
                  </div>
                  <Switch
                    checked={animationsEnabled}
                    onCheckedChange={setAnimationsEnabled}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base">Auto-scroll Chat</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically scroll to new messages
                    </p>
                  </div>
                  <Switch
                    checked={autoScroll}
                    onCheckedChange={setAutoScroll}
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Data Management */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.3 }}
          >
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Data Management</CardTitle>
                <CardDescription>Manage your data and history</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  variant="destructive"
                  onClick={handleClearHistory}
                  className="w-full"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clear Chat History
                </Button>
                <p className="text-xs text-muted-foreground">
                  This will permanently delete all your chat history. This action cannot be undone.
                </p>
              </CardContent>
            </Card>
          </motion.div>

          {/* Save Button */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.4 }}
            className="flex gap-2"
          >
            <Button
              onClick={saveSettings}
              className="flex-1"
            >
              Save Settings
            </Button>
            <Button
              variant="outline"
              onClick={onBack}
              className="flex-1"
            >
              Back
            </Button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

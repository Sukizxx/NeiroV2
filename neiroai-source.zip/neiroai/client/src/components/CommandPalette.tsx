import { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Image, Edit2, Download, Upload, Zap } from "lucide-react";

interface Command {
  id: string;
  label: string;
  description: string;
  icon: React.ReactNode;
  action: () => void;
}

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onCommandSelect: (command: Command) => void;
  inputValue: string;
}

export function CommandPalette({
  isOpen,
  onClose,
  onCommandSelect,
  inputValue,
}: CommandPaletteProps) {
  const [filteredCommands, setFilteredCommands] = useState<Command[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const commands: Command[] = [
    {
      id: "img",
      label: "/img",
      description: "Generate image from text",
      icon: <Image className="w-4 h-4" />,
      action: () => {},
    },
    {
      id: "editimg",
      label: "/editimg",
      description: "Edit uploaded image",
      icon: <Edit2 className="w-4 h-4" />,
      action: () => {},
    },
    {
      id: "download",
      label: "/download",
      description: "Download media from URL",
      icon: <Download className="w-4 h-4" />,
      action: () => {},
    },
    {
      id: "upload",
      label: "/upload",
      description: "Upload file for analysis",
      icon: <Upload className="w-4 h-4" />,
      action: () => {},
    },
    {
      id: "analyze",
      label: "/analyze",
      description: "Analyze code or document",
      icon: <Zap className="w-4 h-4" />,
      action: () => {},
    },
  ];

  // Filter commands based on input
  useEffect(() => {
    if (!isOpen) {
      setFilteredCommands([]);
      return;
    }

    const query = inputValue.replace("/", "").toLowerCase();
    const filtered = commands.filter(
      (cmd) =>
        cmd.label.toLowerCase().includes(query) ||
        cmd.description.toLowerCase().includes(query)
    );

    setFilteredCommands(filtered);
    setSelectedIndex(0);
  }, [inputValue, isOpen]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      switch (e.key) {
        case "ArrowDown":
          e.preventDefault();
          setSelectedIndex((prev) =>
            prev < filteredCommands.length - 1 ? prev + 1 : prev
          );
          break;
        case "ArrowUp":
          e.preventDefault();
          setSelectedIndex((prev) => (prev > 0 ? prev - 1 : prev));
          break;
        case "Enter":
          e.preventDefault();
          if (filteredCommands[selectedIndex]) {
            onCommandSelect(filteredCommands[selectedIndex]);
            onClose();
          }
          break;
        case "Escape":
          e.preventDefault();
          onClose();
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, filteredCommands, selectedIndex, onCommandSelect, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={containerRef}
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
          className="absolute bottom-full mb-2 left-0 right-0 bg-card border border-border rounded-lg shadow-lg overflow-hidden z-50"
        >
          <div className="max-h-64 overflow-y-auto">
            {filteredCommands.length > 0 ? (
              filteredCommands.map((command, index) => (
                <motion.button
                  key={command.id}
                  onClick={() => {
                    onCommandSelect(command);
                    onClose();
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors ${
                    index === selectedIndex
                      ? "bg-accent text-accent-foreground"
                      : "text-foreground hover:bg-secondary"
                  }`}
                  whileHover={{ x: 4 }}
                >
                  <div className="text-muted-foreground">{command.icon}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{command.label}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {command.description}
                    </p>
                  </div>
                </motion.button>
              ))
            ) : (
              <div className="px-4 py-6 text-center text-sm text-muted-foreground">
                No commands found
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

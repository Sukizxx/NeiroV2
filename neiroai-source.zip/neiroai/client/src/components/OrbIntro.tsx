import { useEffect, useState } from "react";
import { motion } from "framer-motion";

interface OrbIntroProps {
  onComplete: () => void;
}

export function OrbIntro({ onComplete }: OrbIntroProps) {
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    // Auto-complete after 3 seconds
    const timer = setTimeout(() => {
      setIsExiting(true);
      setTimeout(onComplete, 600);
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: isExiting ? 0 : 1 }}
      transition={{ duration: 0.6, ease: "easeInOut" }}
      className="fixed inset-0 bg-black flex items-center justify-center z-50"
    >
      {/* Animated Orb Container */}
      <div className="relative w-32 h-32 flex items-center justify-center">
        {/* Outer glow rings */}
        <motion.div
          className="absolute inset-0 rounded-full border border-white/20"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.1, 0.3],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        <motion.div
          className="absolute inset-0 rounded-full border border-white/10"
          animate={{
            scale: [1, 1.4, 1],
            opacity: [0.2, 0.05, 0.2],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.2,
          }}
        />

        {/* Core orb */}
        <motion.div
          className="absolute inset-2 rounded-full bg-gradient-to-br from-white/40 to-white/10 backdrop-blur-sm"
          animate={{
            scale: [1, 1.05, 1],
            boxShadow: [
              "0 0 20px rgba(255, 255, 255, 0.3)",
              "0 0 40px rgba(255, 255, 255, 0.5)",
              "0 0 20px rgba(255, 255, 255, 0.3)",
            ],
          }}
          transition={{
            duration: 2.5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Inner light */}
        <motion.div
          className="absolute inset-4 rounded-full bg-white/20"
          animate={{
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Rotating particles */}
        <motion.div
          className="absolute inset-0 rounded-full"
          animate={{
            rotate: 360,
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "linear",
          }}
        >
          <div className="absolute top-0 left-1/2 w-1 h-1 bg-white rounded-full -translate-x-1/2 -translate-y-2" />
          <div className="absolute top-1/2 right-0 w-1 h-1 bg-white rounded-full translate-x-2 -translate-y-1/2" />
          <div className="absolute bottom-0 left-1/2 w-1 h-1 bg-white rounded-full -translate-x-1/2 translate-y-2" />
          <div className="absolute top-1/2 left-0 w-1 h-1 bg-white rounded-full -translate-x-2 -translate-y-1/2" />
        </motion.div>
      </div>

      {/* Loading text */}
      <motion.div
        className="absolute bottom-20 text-center"
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <p className="text-white/60 text-sm tracking-widest">NeiroAI</p>
      </motion.div>
    </motion.div>
  );
}

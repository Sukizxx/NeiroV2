import { useState } from "react";
import { motion } from "framer-motion";
import { Copy, Check, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface CodeEmbedProps {
  code: string;
  language: string;
  filename?: string;
  showPreview?: boolean;
  onPreviewClick?: () => void;
}

export function CodeEmbed({
  code,
  language,
  filename,
  showPreview = false,
  onPreviewClick,
}: CodeEmbedProps) {
  const [copied, setCopied] = useState(false);
  const [showingPreview, setShowingPreview] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      toast.success("Code copied to clipboard");
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error("Failed to copy code");
    }
  };

  const handlePreviewToggle = () => {
    setShowingPreview(!showingPreview);
    if (!showingPreview && onPreviewClick) {
      onPreviewClick();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="w-full my-4 rounded-lg overflow-hidden border border-border bg-card"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-secondary/50 border-b border-border">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            {filename || language}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {showPreview && language === "html" && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handlePreviewToggle}
              className="h-8 px-2 text-xs"
            >
              {showingPreview ? (
                <>
                  <EyeOff className="w-3 h-3 mr-1" />
                  Hide
                </>
              ) : (
                <>
                  <Eye className="w-3 h-3 mr-1" />
                  Preview
                </>
              )}
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={handleCopy}
            className="h-8 px-2 text-xs"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 mr-1" />
                Copy
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Code */}
      <div className="overflow-x-auto">
        <pre className="p-4 text-sm font-mono text-foreground bg-background">
          <code>{code}</code>
        </pre>
      </div>

      {/* Preview (for HTML) */}
      {showPreview && language === "html" && showingPreview && (
        <div className="border-t border-border p-4 bg-white">
          <iframe
            srcDoc={code}
            className="w-full h-96 border border-border rounded"
            sandbox="allow-scripts"
            title="HTML Preview"
          />
        </div>
      )}
    </motion.div>
  );
}

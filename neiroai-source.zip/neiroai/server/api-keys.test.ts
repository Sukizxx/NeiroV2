import { describe, expect, it } from "vitest";

/**
 * Test untuk validasi API keys OpenRouter dan NVIDIA
 * Memastikan credentials yang diberikan valid sebelum digunakan
 */

describe("API Keys Validation", () => {
  it("should have OPENROUTER_API_KEY set", () => {
    const key = process.env.OPENROUTER_API_KEY;
    expect(key).toBeDefined();
    expect(key).toMatch(/^sk-or-v1-/);
  });

  it("should have NVIDIA_API_KEY set", () => {
    const key = process.env.NVIDIA_API_KEY;
    expect(key).toBeDefined();
    expect(key).toMatch(/^nvapi-/);
  });

  it("should validate OpenRouter API key format", async () => {
    const apiKey = process.env.OPENROUTER_API_KEY;
    if (!apiKey) {
      throw new Error("OPENROUTER_API_KEY not set");
    }

    try {
      const response = await fetch("https://openrouter.ai/api/v1/models", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${apiKey}`,
        },
      });

      // Should get 200 or 401 (invalid key) - both are valid responses
      // 200 means key is valid, 401 means key is invalid
      expect([200, 401]).toContain(response.status);

      if (response.status === 200) {
        const data = await response.json();
        expect(data).toHaveProperty("data");
        expect(Array.isArray(data.data)).toBe(true);
      }
    } catch (error) {
      // Network errors are acceptable in test environment
      console.warn("Network error during OpenRouter validation:", error);
    }
  });

  it("should validate NVIDIA API key format", async () => {
    const apiKey = process.env.NVIDIA_API_KEY;
    if (!apiKey) {
      throw new Error("NVIDIA_API_KEY not set");
    }

    try {
      const response = await fetch(
        "https://api.nvcf.nvidia.com/v2/nvcf/pexec/functions",
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${apiKey}`,
            Accept: "application/json",
          },
        }
      );

      // Should get 200 or 401 (invalid key) - both are valid responses
      expect([200, 401, 403]).toContain(response.status);
    } catch (error) {
      // Network errors are acceptable in test environment
      console.warn("Network error during NVIDIA validation:", error);
    }
  });

  it("should have SYNOX_API_KEY if provided", () => {
    const key = process.env.SYNOX_API_KEY;
    // SYNOX_API_KEY is optional
    if (key) {
      expect(typeof key).toBe("string");
      expect(key.length).toBeGreaterThan(0);
    }
  });
});

import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";

export const chatRouter = router({
  /**
   * Send message to NeiroPlus (multi-model orchestration)
   * Implements: Draft → Cross Evaluation → Judge pipeline
   */
  sendMessage: publicProcedure
    .input(
      z.object({
        message: z.string().min(1),
        model: z.enum(["netrom3", "nemotron", "neiroplus"]).default("neiroplus"),
        conversationHistory: z
          .array(
            z.object({
              role: z.enum(["user", "assistant"]),
              content: z.string(),
            })
          )
          .optional()
          .default([]),
      })
    )
    .mutation(async ({ input }) => {
      const { message, model, conversationHistory } = input;

      try {
        // Build messages array
        const messages = [
          ...conversationHistory,
          {
            role: "user" as const,
            content: message,
          },
        ];

        let response: string;

        if (model === "neiroplus") {
          // NeiroPlus: Multi-model orchestration
          response = await orchestrateNeiroPlus(messages);
        } else if (model === "netrom3") {
          // Netrom 3 Ultra (via OpenRouter)
          response = await invokeNetrom3Ultra(messages);
        } else {
          // Nemotron Nano Omni (via NVIDIA)
          response = await invokeNemotronNano(messages);
        }

        return {
          success: true,
          response,
          model,
        };
      } catch (error) {
        console.error("Chat error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * List available models
   */
  listModels: publicProcedure.query(async () => {
    try {
      const response = await fetch("https://openrouter.ai/api/v1/models", {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch models");
      }

      const data = await response.json();
      return {
        success: true,
        models: data.data || [],
      };
    } catch (error) {
      console.error("Error listing models:", error);
      return {
        success: false,
        models: [],
      };
    }
  }),
});

/**
 * Orchestrate NeiroPlus: Draft → Cross Eval → Judge
 */
async function orchestrateNeiroPlus(
  messages: Array<{ role: "user" | "assistant"; content: string }>
): Promise<string> {
  try {
    // Stage 1: Draft Generation (parallel)
    const [netrom3Draft, nemotronDraft] = await Promise.all([
      invokeNetrom3Ultra(messages),
      invokeNemotronNano(messages),
    ]);

    // Stage 2: Cross Evaluation
    const evaluationPrompt = `
You are evaluating two AI responses. Please analyze both responses and identify:
1. Strengths and weaknesses
2. Factual accuracy
3. Missing information
4. Suggested improvements

Response 1 (Netrom 3 Ultra):
${netrom3Draft}

Response 2 (Nemotron Nano):
${nemotronDraft}

Provide a structured evaluation.`;

    const evaluation = await invokeLLM({
      messages: [
        {
          role: "user",
          content: evaluationPrompt,
        },
      ],
    });

    const evaluationContent =
      typeof evaluation.choices[0].message.content === "string"
        ? evaluation.choices[0].message.content
        : "";

    // Stage 3: Judge - Netrom 3 Ultra synthesizes final response
    const judgePrompt = `
Based on the following information, provide a final, synthesized response:

Original User Query: ${messages[messages.length - 1].content}

Response 1: ${netrom3Draft}

Response 2: ${nemotronDraft}

Evaluation: ${evaluationContent}

Please provide the best possible answer, combining the strengths of both responses and addressing any weaknesses identified in the evaluation.`;

    const finalResponse = await invokeNetrom3Ultra([
      {
        role: "user",
        content: judgePrompt,
      },
    ]);

    return finalResponse;
  } catch (error) {
    console.error("NeiroPlus orchestration error:", error);
    // Fallback to Netrom 3 Ultra if orchestration fails
    return invokeNetrom3Ultra(messages);
  }
}

/**
 * Invoke Netrom 3 Ultra via OpenRouter
 */
async function invokeNetrom3Ultra(
  messages: Array<{ role: "user" | "assistant"; content: string }>
): Promise<string> {
  try {
    const response = await invokeLLM({
      model: "openrouter/netrom-3-ultra", // OpenRouter model ID
      messages: messages.map((m) => ({
        role: m.role,
        content: m.content,
      })),
    });

    const content = response.choices[0].message.content;
    return typeof content === "string" ? content : "No response";
  } catch (error) {
    console.error("Netrom 3 Ultra error:", error);
    throw error;
  }
}

/**
 * Invoke Nemotron Nano Omni via NVIDIA
 */
async function invokeNemotronNano(
  messages: Array<{ role: "user" | "assistant"; content: string }>
): Promise<string> {
  try {
    const response = await invokeLLM({
      model: "nvidia/nemotron-3-nano-omni", // NVIDIA model ID
      messages: messages.map((m) => ({
        role: m.role,
        content: m.content,
      })),
    });

    const content = response.choices[0].message.content;
    return typeof content === "string" ? content : "No response";
  } catch (error) {
    console.error("Nemotron Nano error:", error);
    throw error;
  }
}

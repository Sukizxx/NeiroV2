# NeiroAI - Project TODO

## Core UI & Layout
- [x] Animated Orb intro screen (futuristik, monochrome, halus)
- [x] Sidebar hamburger menu dengan slide in/out animation
- [x] Chat interface dengan bubble modern (user & AI)
- [ ] Responsive layout mobile-first (44px+ touch targets)
- [x] Color system: #000000, #1A1A1A, #2A2A2A, #FFFFFF, #BFBFBF, #333333, #3A3A3A
- [ ] Typography: Inter/Geist fonts

## Chat System & Streaming
- [x] Streaming response stabil (anti-flicker, anti-screen-shake)
- [x] Auto-scroll cerdas (berhenti saat user scroll ke atas)
- [x] Stop button yang selalu berfungsi
- [x] Text overflow fix (auto-wrap, no horizontal scroll)
- [ ] Message actions: Edit, Copy, Select Text (user), Copy & Select Text (AI)

## Model & AI Integration
- [x] Model selector dropdown (Netrom 3 Ultra, Nemotron Nano Omni, NeiroPlus)
- [x] NeiroPlus orchestration (Draft → Cross Eval → Judge)
- [x] Netrom 3 Ultra sebagai Chief Judge & Coding Specialist
- [x] Nemotron Nano Omni untuk vision/image understanding
- [ ] Failsafe system (auto-skip jika model timeout/error)
- [ ] Thinking mode UI (Thinking, Reasoning, Analyzing, Planning)
- [ ] AI Discussion mode dengan avatar & bubble terpisah

## Code Embed & Developer Experience
- [x] Code embed system (dark theme, rounded, modern)
- [x] Copy button dengan animasi sukses
- [ ] Support semua bahasa: HTML, CSS, JS, TS, Python, PHP, Go, Rust, Java, C, C++, C#, Bash, SQL, JSON, YAML
- [x] HTML special treatment: Code tab + Preview tab
- [x] HTML Preview sandbox (render HTML/CSS/JS langsung)
- [ ] Multiple embeds stack (vertikal/collapsible)
- [ ] File labeling jelas (index.html, style.css, script.js)

## File System & Media
- [ ] File upload system (JPG, JPEG, PNG, WEBP, GIF, PDF, DOCX, TXT, ZIP)
- [ ] File preview card (nama, ukuran, tipe, thumbnail)
- [ ] Image understanding (OCR, screenshot analysis, object detection)
- [ ] PDF analysis (ringkas, Q&A, ekstrak info penting)
- [ ] DOCX analysis (baca, analisis, ringkas)
- [ ] ZIP extraction (ekstrak, tree structure display)
- [ ] Source code analysis (baca project, find bugs, suggest optimizations)

## Auto Tool Detection & Command Palette
- [ ] Auto detect image generation intent
- [ ] Auto detect image edit intent
- [ ] Auto detect download intent
- [x] Command palette (/) dengan perintah: /img, /editimg, /download, /upload, /analyze
- [x] Smooth popup animation untuk command palette

## Media Tools & Synox Integration
- [ ] Image generation via Synox (text-2-image endpoint)
- [ ] Image editing via Synox (nanobanana endpoint)
- [ ] Catbox uploader untuk temporary image URLs
- [ ] Image viewer (zoom, preview, download)
- [ ] Media downloader (TikTok, IG, FB, Reddit, YouTube, Twitter, Pinterest, Telegram, LinkedIn, Vimeo, Spotify, SoundCloud)
- [ ] Download quality rule (HD no watermark priority)
- [ ] Video player (play, download, preview)

## Built-in Image Generation
- [ ] Image generation helper sebagai fallback
- [ ] Direct image display di chat (bukan link mentah)
- [ ] Image viewer integration

## Chat History & Context Management
- [ ] localStorage untuk menyimpan chat history
- [ ] Auto-generated chat titles
- [ ] Chat actions: Rename, Delete, Create, Reopen
- [ ] New Chat logic (clear context, save history)
- [ ] Chat list di sidebar

## Settings Page
- [x] Theme settings (dark/light)
- [x] Model default selector
- [x] Animation preferences
- [x] Clear history button

## Performance & Responsiveness
- [ ] 60 FPS animation target
- [ ] Mobile-first responsive design
- [ ] No horizontal scroll global
- [ ] Smooth transitions & animations
- [ ] Optimized re-renders

## API Integration
- [x] OpenRouter API integration (Netrom 3 Ultra, GPT-OSS)
- [x] NVIDIA API integration (Nemotron Nano Omni)
- [ ] Synox REST API integration (image gen, edit, download)
- [ ] S3 storage integration untuk file uploads
- [ ] Error handling & failsafe

## Testing & Quality
- [x] Vitest unit tests untuk API keys validation
- [ ] Browser testing untuk UI interactions
- [ ] Responsive design testing (mobile, tablet, desktop)
- [ ] Performance profiling

## Deployment & Delivery
- [x] Environment variables setup (OpenRouter, NVIDIA, Synox)
- [ ] Production build optimization
- [ ] ZIP file packaging
- [ ] Documentation

## Integration Status
- [x] NeiroChat page dengan Orb intro
- [x] Sidebar navigation dengan model selector
- [x] Chat interface dengan streaming simulation
- [x] tRPC chat router integration
- [x] Command palette component
- [x] Settings page (theme, model, preferences)
- [x] Code embed component dengan HTML preview
- [x] Chat history localStorage persistence
- [x] Media router skeleton (ready untuk Synox integration)
- [ ] Real streaming implementation (backend SSE)
- [ ] Synox integration (image gen, edit, download)
- [ ] File upload & analysis workflow
